<?php
// Heading
$_['lang_heading_title']        = 'Page cache';
// Text
?>
